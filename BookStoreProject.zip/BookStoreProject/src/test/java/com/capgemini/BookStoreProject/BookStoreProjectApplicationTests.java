package com.capgemini.BookStoreProject;


//
//@RunWith(SpringRunner.class)
//@SpringBootTest
//public class BookStoreProjectApplicationTests {
//
//	@Test
//	public void contextLoads() {
//	}
//
//}
