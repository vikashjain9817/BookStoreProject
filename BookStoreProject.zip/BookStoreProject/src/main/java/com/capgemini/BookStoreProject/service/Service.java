package com.capgemini.BookStoreProject.service;

import java.util.List;
import java.util.Map;

import com.capgemini.BookStoreProject.beans.Book;
import com.capgemini.BookStoreProject.beans.Orders;
import com.capgemini.BookStoreProject.beans.RegisterCustomer;

import com.capgemini.BookStoreProject.exceptions.BookCannotBeAddedMoreAsItIsOutOfStockException;
import com.capgemini.BookStoreProject.exceptions.BookDoesNotExistException;
import com.capgemini.BookStoreProject.exceptions.CustomerAlreadyExistException;


public interface Service {
	
	public RegisterCustomer registerCustomer(RegisterCustomer customer) throws CustomerAlreadyExistException;
	
	public String clearCart();
	
	public Map<Integer, Book> addABookToCart(Book book);
	
	public Map<Integer, Book> removeABookFromCart(int bookId) throws BookDoesNotExistException;
	
	public Map<Integer, Book> addQuantityOfBook(int bookId) throws BookCannotBeAddedMoreAsItIsOutOfStockException;
	
	public Map<Integer, Book> decreaseQuantityOfBook(int bookId);
	
	
	public List<RegisterCustomer> listAllCutomers();

	public List<Orders> getOrdersForAdmin();

	public Orders getOrderDeatilsByOrderId(int orderId);

	public List<Orders> confirmOrder(Orders order);

	public List<Orders> findAllOrdersOfPerticularCustomer(int customerId);
}
