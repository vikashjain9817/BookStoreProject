package com.capgemini.BookStoreProject.dao;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.BookStoreProject.beans.Book;



public class CustomerCartManagementImpl implements CustomerCartManagement {
	

	

	static Map<Integer,Book> cart = new HashMap<>();
	/*static {
		Book book = new Book();
		Category category = new Category();
		category.setCategoryId(500);
		category.setCategoryName("health");
		book.setAuthorName("vikash");
		book.setBookId(100);
		book.setBookImage("image.jpg");
		book.setCategory(category);
		book.setDesription("heath is welath");
		book.setIsbn("tatti");
		book.setPrice(123.56);
		book.setPublishDate((LocalDate.now()));
		
		
		
		book
		cart.put(200, book);
	}*/
	
	
	@Override
	public void clearCart() {
		cart.clear();
		
	}

	@SuppressWarnings("unlikely-arg-type")
	@Override
	public Map<Integer,Book> removeABookFromCart(int bookId) {
		Book book = cart.get(bookId);
		cart.remove(book);
		return cart;

	}

	@Override
	public Map<Integer,Book> addABookToCart(Book book) {
		
		cart.put(book.getBookId(), book);
		return cart;
	}
	
	@Override
	public Map<Integer,Book> addQuantityOfABook(int bookId) {
		Book book = cart.get(bookId);
		book.setQuantity(book.getQuantity()+1);
		return cart;
	}

	@Override
	public Book searchBook(int bookId) {
		Book book = cart.get(bookId);
		return book;
	}

	@Override
	public Map<Integer, Book> decreaseQuantityOfABook(int bookId) {
		Book book = cart.get(bookId);
		book.setQuantity(book.getQuantity()-1);
		return cart;
		}
	}
