package com.capgemini.BookStoreProject.beans;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;


@Entity
@Table(name="Book")
@SequenceGenerator(name = "bookseq", initialValue=100, allocationSize=4)
public class Book {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="bookseq")
	@Column(name = "bookId")
	private int bookId;
	
	@OneToOne(cascade = CascadeType.ALL)
	@NotNull
	@JoinColumn(name = "categoryId")
	private Category category;
	
	@Column(name = "authorName")
	private String authorName;
	
	@NotNull
	@Column(name = "isbn")
	private String isbn;
	    
	@Column(name = "title")
	private String title;
	
	@Column(name = "price")
	private double price;
	    
	@Column(name = "description") 
    private String desription;
	
	@NotNull
	@Column(name = "quantity")
	private Integer quantity;
	
	@Column(name = "publishDate")
	private Date publishDate;
	
	@Column(name = "rating")
	private Integer rating;
	    
	@Column(name = "bookImage")
	private String bookImage;

	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public String getAuthorName() {
		return authorName;
	}

	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getDesription() {
		return desription;
	}

	public void setDesription(String desription) {
		this.desription = desription;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public Date getPublishDate() {
		return publishDate;
	}

	public void setPublishDate(Date publishDate) {
		this.publishDate = publishDate;
	}

	public Integer getRating() {
		return rating;
	}

	public void setRating(Integer rating) {
		this.rating = rating;
	}

	public String getBookImage() {
		return bookImage;
	}

	public void setBookImage(String bookImage) {
		this.bookImage = bookImage;
	}

	public Book(int bookId, Category category, String authorName, String isbn, String title, double price,
			String desription, Integer quantity, Date publishDate, Integer rating, String bookImage) {
		super();
		this.bookId = bookId;
		this.category = category;
		this.authorName = authorName;
		this.isbn = isbn;
		this.title = title;
		this.price = price;
		this.desription = desription;
		this.quantity = quantity;
		this.publishDate = publishDate;
		this.rating = rating;
		this.bookImage = bookImage;
	}

	public Book() {
		super();
		
	}
	
	
	
}