package com.capgemini.BookStoreProject.beans;

public class Cart {

	private Book book;
	private double total;
	
	public Book getBook() {
		return book;
	}
	public void setBook(Book book) {
		this.book = book;
	}
	public double getTotal() {
		return total;
	}
	public void setTotal(double total) {
		this.total = total;
	}
	
	public Cart( Book book, double total) {
		super();
		
		this.book = book;
		this.total = total;
		
	}
	public Cart() {
		super();

	}
	
	
}
