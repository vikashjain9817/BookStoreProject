package com.capgemini.BookStoreProject.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.BookStoreProject.beans.Orders;

public interface IOrdersDAO extends JpaRepository<Orders, Integer> {

}
