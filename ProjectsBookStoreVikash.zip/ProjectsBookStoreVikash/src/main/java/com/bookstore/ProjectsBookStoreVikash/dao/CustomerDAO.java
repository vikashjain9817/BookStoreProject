package com.bookstore.ProjectsBookStoreVikash.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bookstore.ProjectsBookStoreVikash.beans.Customer;

public interface CustomerDAO extends JpaRepository<Customer, Integer> {

}
