package com.bookstore.ProjectsBookStoreVikash.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bookstore.ProjectsBookStoreVikash.beans.Book;
import com.bookstore.ProjectsBookStoreVikash.beans.CartItem;
import com.bookstore.ProjectsBookStoreVikash.beans.Category;
import com.bookstore.ProjectsBookStoreVikash.beans.Orders;
import com.bookstore.ProjectsBookStoreVikash.dao.BookDAO;
import com.bookstore.ProjectsBookStoreVikash.dao.CartDAOImpl;
import com.bookstore.ProjectsBookStoreVikash.dao.CategoryDAO;
import com.bookstore.ProjectsBookStoreVikash.dao.CustomerDAO;
import com.bookstore.ProjectsBookStoreVikash.dao.ICartDAO;
import com.bookstore.ProjectsBookStoreVikash.dao.OrdersDAO;

@Service
public class BookStoreImpl implements IBookStore {
	
	@Autowired
	BookDAO bookDAO;
	
	@Autowired
	CustomerDAO customerDAO;
	
	@Autowired
	OrdersDAO ordersDAO;
	
	@Autowired
	CategoryDAO categoryDAO;
	
	ICartDAO cartDAO = new CartDAOImpl();
	
	@Override
	public List<Orders> getOrdersForAdmin(){
			List<Orders> orders = ordersDAO.findAll();
			System.out.println(orders);
			return orders;
	}
	
	@Override
	public Orders getOrderDeatilsByOrderId(int orderId) {
		Orders order = new Orders();
		order = ordersDAO.findById(orderId).get();
		return order;
	}
	
	@Override
	public Map<Integer, CartItem> buyBook(Book book) {
		cartDAO.add(book);
		return cartDAO.getCart();
	}
	
	@Override
	public void confirmOrder(Orders order) {
		ordersDAO.save(order);
	}
	
	@Override
	public void updateOrderByAdmin(Orders order)
	{
		ordersDAO.saveAndFlush(order);
	}
	
	@Override
	public void updateShoppingCart(CartItem item)
	{
		cartDAO.updateCart(item);
	}
	
	@Override
	public void createCategory(Category category){
		categoryDAO.save(category);
	}
	/*
	public void addBookByTheAdminToAPerticularOrder(int orderId)
	{
		Orders order = new Orders();
		order = ordersDAO.findOne(orderId);
		order.setBookCopies(order.getBookCopies() + 1);
		ordersDAO.saveAndFlush(order);
	}
	
	public void subtractBookByTheAdminToAPerticularOrder(int orderId)
	{
		Orders order = new Orders();
		order = ordersDAO.findOne(orderId);
		order.setBookCopies(order.getBookCopies() - 1);
		ordersDAO.saveAndFlush(order);
	}
	
	public void updateRecipientDetails(int orderId)
	{
		Orders order = new Orders();
		order = ordersDAO.findOne(orderId);
		
		
	}
	*/
}


