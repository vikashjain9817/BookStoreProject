package com.bookstore.ProjectsBookStoreVikash;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectsBookStoreVikashApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectsBookStoreVikashApplication.class, args);
	}

}