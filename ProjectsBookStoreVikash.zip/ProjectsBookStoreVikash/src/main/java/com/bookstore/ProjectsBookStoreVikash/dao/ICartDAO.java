package com.bookstore.ProjectsBookStoreVikash.dao;


import java.util.Map;

import com.bookstore.ProjectsBookStoreVikash.beans.Book;
import com.bookstore.ProjectsBookStoreVikash.beans.CartItem;

public interface ICartDAO {

	void add(Book book);
	
	double getPrice();

	void setPrice(double price);
	
	public void updateCart(CartItem item);
	
	public Map<Integer, CartItem> getCart();

}