package com.bookstore.ProjectsBookStoreVikash.service;

import java.util.List;
import java.util.Map;

import com.bookstore.ProjectsBookStoreVikash.beans.Book;
import com.bookstore.ProjectsBookStoreVikash.beans.CartItem;
import com.bookstore.ProjectsBookStoreVikash.beans.Category;
import com.bookstore.ProjectsBookStoreVikash.beans.Orders;

public interface IBookStore {

	List<Orders> getOrdersForAdmin();

	Orders getOrderDeatilsByOrderId(int orderId);

	Map<Integer, CartItem> buyBook(Book book);

	void confirmOrder(Orders order);

	void updateOrderByAdmin(Orders order);

	void updateShoppingCart(CartItem item);

	void createCategory(Category category);

}