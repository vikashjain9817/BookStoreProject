package com.bookstore.ProjectsBookStoreVikash.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bookstore.ProjectsBookStoreVikash.beans.Book;

public interface BookDAO extends JpaRepository<Book, Integer>{

}
