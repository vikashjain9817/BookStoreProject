package com.bookstore.ProjectsBookStoreVikash.dao;

import java.util.HashMap;
import java.util.Map;

import com.bookstore.ProjectsBookStoreVikash.beans.Book;
import com.bookstore.ProjectsBookStoreVikash.beans.CartItem;

public class CartDAOImpl implements ICartDAO {
	
	private Map<Integer, CartItem> map = new HashMap<Integer, CartItem>();
	private double price;
	
	@Override
	public void add(Book book){
		CartItem item = map.get(book.getBookId());
		if(item ==null){
			item = new CartItem();
			item.setBook(book);
			item.setQuantity(1);
			map.put(book.getBookId(), item);
		}else{
			item.setQuantity(item.getQuantity() + 1);
		}
	}
	
	@Override
	public void updateCart(CartItem item)
	{
		map.put(item.getBook().getBookId(), item);
	}
	
	@Override
	public double getPrice() {
		
		double totalprice = 0;
		for(Map.Entry<Integer, CartItem> me : map.entrySet()){
			CartItem item = me.getValue();
			totalprice = totalprice + item.getPrice();
		}
		this.price = totalprice;
		return price;
	}
	
	
	@Override
	public void setPrice(double price) {
		this.price = price;
	}

	@Override
	public Map<Integer, CartItem> getCart() {
		return map;
	}
}
