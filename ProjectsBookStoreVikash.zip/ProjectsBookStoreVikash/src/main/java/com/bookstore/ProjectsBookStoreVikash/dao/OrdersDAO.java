package com.bookstore.ProjectsBookStoreVikash.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bookstore.ProjectsBookStoreVikash.beans.Orders;

public interface OrdersDAO extends JpaRepository<Orders, Integer>{

}
