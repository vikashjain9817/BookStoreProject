package com.capgemini.ProjectsBookStoreVikash.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.bookstore.ProjectsBookStoreVikash.beans.Book;
import com.bookstore.ProjectsBookStoreVikash.beans.CartItem;
import com.bookstore.ProjectsBookStoreVikash.beans.Category;
import com.bookstore.ProjectsBookStoreVikash.beans.Orders;
import com.bookstore.ProjectsBookStoreVikash.service.IBookStore;

@Controller
public class BookStoreController {

	@Autowired
	IBookStore bookStoreService;
	
	@RequestMapping(value = "/")
	public String home() 
	{
		return "home";
	}
	
	@RequestMapping(value = "/getOrdersForAdmin", method = RequestMethod.GET)
	public List<Orders> getOrdersAdmin() {
			return bookStoreService.getOrdersForAdmin();
	}
	
	
	@RequestMapping(value = "/orderDetail/{orderId}", method = RequestMethod.GET)
	public Orders getOrderDetails(@PathVariable int orderId) {
			return bookStoreService.getOrderDeatilsByOrderId(orderId);
	}
	
	@RequestMapping(value = "/buybook", method = RequestMethod.PUT)
	public Map<Integer, CartItem> buyBook(@RequestBody Book book) {
			return bookStoreService.buyBook(book);
	}
	
	@RequestMapping(value = "/confirmOrder", method = RequestMethod.PUT)
	public String confirmOrder(@RequestBody Orders order) {
			bookStoreService.confirmOrder(order);
			return "order placed successfully";
	}
	
	@RequestMapping(value = "/updateOrderByAdmin", method = RequestMethod.PUT)
	public String updateOrderByAdmin(@RequestBody Orders order) {
			bookStoreService.updateOrderByAdmin(order);
			return "order updated successfully";
	}
	
	
	@RequestMapping(value = "/updateCart", method = RequestMethod.PUT)
	public String updateCart(@RequestBody CartItem item) {
			bookStoreService.updateShoppingCart(item);
			return "cart updated successfully";
	}
	
	@RequestMapping(value = "/createCategory", method = RequestMethod.GET)
	public String createCategory(@RequestBody Category category) {
			bookStoreService.createCategory(category);
			return "created successfully";
			
	}
	
	
}
