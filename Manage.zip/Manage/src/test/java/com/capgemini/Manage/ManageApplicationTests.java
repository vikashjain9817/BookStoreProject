package com.capgemini.Manage;

import org.junit.Test;
import org.junit.runner.RunWith;

/*
@RunWith(SpringRunner.class)
@SpringBootTest
public class ManageApplicationTests {

	@Test
	public void contextLoads() {
	}

}
*/
