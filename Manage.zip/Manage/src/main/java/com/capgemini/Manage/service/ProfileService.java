package com.capgemini.Manage.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.Manage.bean.Customer;
import com.capgemini.Manage.dao.CustomerRepository;

@Service
public class ProfileService implements PofileInterface {
	
	@Autowired
	CustomerRepository repository;
	
	
	@Override
	public Customer viewProfile(int customerId)
	{
		System.out.println("hello this is service");
		System.out.println(repository.getOne(customerId));
		return repository.getOne(customerId);
	}
	
	
	@Override
	public Customer editProfile(Customer customer)
	{
		Customer cust = repository.findById(customer.getCustomerId()).get();
		cust.setCustomerName(customer.getCustomerName());
		cust.setEmail(customer.getEmail());
		cust.setPassword(customer.getPassword());
		cust.setPhoneNumber(customer.getPhoneNumber());
		cust.setAddress(customer.getAddress());
		cust.setCity(customer.getCity());
		cust.setZipCode(customer.getZipCode());
		cust.setCountry(customer.getCountry());
		repository.save(cust);
		
		return cust;	
	}

}
