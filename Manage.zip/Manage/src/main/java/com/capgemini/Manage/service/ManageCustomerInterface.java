package com.capgemini.Manage.service;

import java.util.List;

import com.capgemini.Manage.bean.Customer;
import com.capgemini.Manage.exception.emptyListException;

public interface ManageCustomerInterface {

	Customer createCustomer(Customer customer);

	Customer deleteCustomer(int customerId);

	List<Customer> listAllCustomer() throws emptyListException;

	Customer editCustomer(Customer customer);

}